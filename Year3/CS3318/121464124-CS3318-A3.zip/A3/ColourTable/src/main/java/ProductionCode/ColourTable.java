package ProductionCode;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ColourTable {
    /*
     * Class Production.ColourTable interacts with TestCode.TestDriverCode file.
     * This class contains a couple of constructors in-order to catch Missing Inputs/Null, Strings and Float.
     * This class only allows an intake of an Integer.
     * Integer must be of size 2 or greater, but less than 1025.
     * Integer must be a Power of Two (2^x).
     * */
//    Creation of ArrayList to be used in Production.ColourTable object.
        ArrayList<String> table = new ArrayList<>();
//        Int Variable to use in Creation of ArrayList.
        int ArraySize;
    public ColourTable() {
        /*
         * This method catches instantiation of the Production.ColourTable object without specifying a valid size.
         * */
//        Prints out Error.
        System.out.println("Invalid or Null input, specify length of Pallet.");
    }
    public ColourTable(String s) {
        /*
        * This method catches instantiation of the Production.ColourTable object when a String is used.
        * */
//        Prints out Error.
        System.out.println("Invalid input: " + s + ", should be of Integer.");
    }
    public ColourTable(float v) {
        /*
         * This method catches instantiation of the Production.ColourTable object when a String is used.
         * */
//        Prints out Error.
        System.out.println("Invalid Input: " + v + ", should be of Integer.");
    }
    public ColourTable(int i) {
//        Check for correct size of Int.
        if (1 < i && i < 1025) {
            //        Check for valid Power of 2
            //        Equation source: https://codereview.stackexchange.com/questions/172849/checking-if-a-number-is-power-of-2-or-not
            if ((i & (i - 1)) == 0) {
                ArraySize = i;
                return;
            }
            System.out.println("Invalid Array size. Should be Power of 2");
        } else {
            System.out.println("Out of Bound Array size.");
        }
    }
//    Method for adding String to Array
    public void addColour(String hexString) {
//        Verifying Input String for valid RGB Colour.
        if (!validRGB(hexString)) {
//            Verifying Input Sting is valid without # in it.
            if (validRGBNoHashTag(hexString)) {
                table.add("#" + hexString);
                return;
            }
            System.out.println("HexString: "+ hexString + " is Invalid");
            return;
        }
//        Checking Input String for duplicate entries.
        if (table.contains(hexString)) System.out.println("Note: Duplicate Colour added.");
//        Verifying Cap of ArrayList is not surpassed.
        if (table.size() == ArraySize) {
            System.out.println("Cannot add Colour. Max Pallet Size reached.");
            return;
        }
//        using ArrayList 'add' method for the object.
        table.add(hexString);
    }
//    Method for checking if RGB Colour is Valid using Regular Expression & ReGex
//    source: https://www.geeksforgeeks.org/how-to-validate-hexadecimal-color-code-using-regular-expression/
    public boolean validRGB(String hex) {
        // Regex to check valid hexadecimal color code.
        String regex = "^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$";

        // Compile the ReGex
        Pattern p = Pattern.compile(regex);

        // If the string is empty
        // return false
        if (hex == null) {
            return false;
        }

        // Pattern class contains matcher() method
        // to find matching between given string
        // and regular expression.
        Matcher m = p.matcher(hex);

        // Return if the string
        // matched the ReGex
        return m.matches();
    }
//    Same method as above, except without HashTag.
    public boolean validRGBNoHashTag(String hex) {
        // Regex to check valid hexadecimal color code.
        String regex = "^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$";

        // Compile the ReGex
        Pattern p = Pattern.compile(regex);

        // If the string is empty
        // return false
        if (hex == null) {
            return false;
        }

        // Pattern class contains matcher() method
        // to find matching between given string
        // and regular expression.
        Matcher m = p.matcher(hex);

        // Return if the string
        // matched the ReGex
        return m.matches();
    }
//    Method for getting size of ArrayList.
    public int getSize() {
        return table.size();
    }
//    Method for getting all the elements of the ArrayList.
    public StringBuilder listColours() {
//        Creation of final StringBuilder variable.
        final StringBuilder myColourList = new StringBuilder();
//        Checker for size of list as if it is bigger than 1, we will need to add comma & space to it.
        if (table.size() > 1 ){
            table.forEach(el-> myColourList.append("|").append(el).append("| "));
            return myColourList;
        }
        myColourList.append("|").append(table.get(0)).append("|");
        return myColourList;
    }
}
