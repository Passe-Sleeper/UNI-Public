package TestCode;

import ProductionCode.ColourTable;

public class TestDriverCode {
    public static void main(String[] args) {
//        Initial test to make sure file is running.
        System.out.println("Hello World");
//        Counter for tests (above Hello World test does not count!)
        int testNum =0;
//        Series of tests
        System.out.println("\nTest 1: Creating Constructor Obj.");
        createConstr();
        testNum++; // 1
        System.out.println("\nTest 2: Inputting String for Array Size");
        inputStrForArraySize();
        testNum++; // 2
        System.out.println("\nTest 3: Inputting Float for Array Size");
        inputFloForArraySize();
        testNum++; // 3
        System.out.println("\nTest 4: Inputting Too Small Int for Array Size");
        inputTooSmallForArraySize();
        testNum++; // 4
        System.out.println("\nTest 5: Inputting Too Big Int for Array Size");
        inputTooBigForArraySize();
        testNum++; // 5
        System.out.println("\nTest 6: Inputting Non Power of Two for Array Size");
        inputNotPowerOfTwoForArraySize();
        testNum++; // 6
        System.out.println("\nTest 7: Adding RGB Colour to Array");
        addMethodForConstr();
        testNum++; // 7
        System.out.println("\nTest 8: Validation for RGB Colours");
        validRGBColour();
        testNum++; // 8
        System.out.println("\nTest 9: Getting Size of Array method");
        getSizeMethodForConstr();
        testNum++; // 9
        System.out.println("\nTest 10: Listing Elements of ArrayList: ");
        listColoursMethodForConstr();
        testNum++; // 10
        System.out.println("\nTest 11: Adding duplicate entries to ArrayList");
        addingDuplicatesToArray();
        testNum++; // 11
        System.out.println("\nTest 12: Going over Array Limit");
        goingOverArrayLimit();
        testNum++; // 12
//        Printing out number of Trials Completed
        System.out.println("\n" + testNum + " tests completed with 0 errors.");
    }
//    Creating Production.ColourTable obj.
    static void createConstr(){
//        Encapsulated in a try method.
        try {
            ColourTable ct = new ColourTable();
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Adding input String to Production.ColourTable obj.
    static void inputStrForArraySize() {
        try{
//        Encapsulated in a try method.
            ColourTable ctStr = new ColourTable("1");
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Adding input Float to Production.ColourTable obj.
    static void inputFloForArraySize() {
        try{
//        Encapsulated in a try method.
            ColourTable ctFlo = new ColourTable(1F);
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Testing for input Size being too small.
    static void inputTooSmallForArraySize() {
        try{
            ColourTable ctSmallInt = new ColourTable(1);
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Testing for input Size being too large.
    static void inputTooBigForArraySize() {
        try{
            ColourTable ctBigInt = new ColourTable(1025);
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Checking for Power of 2.
    static void inputNotPowerOfTwoForArraySize() {
        try{
            ColourTable ctNonSquareInt = new ColourTable(25);
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Using method addColour to add elements to Array.
    static void addMethodForConstr() {
        try{
            ColourTable ctAddMethod = new ColourTable(4);
            ctAddMethod.addColour("#123AAA");
//            went back and added the following line to check contents of object.
//            System.out.println(ctValidRGB.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Testing for valid RGB colour being added.
    static void validRGBColour() {
        try{
            ColourTable ctValidRGB = new ColourTable(4);
            ctValidRGB.addColour("thisiswrong"); // should return False
            ctValidRGB.addColour("#1232345"); // should return False
            ctValidRGB.addColour("FFDF12"); // should return False
            ctValidRGB.addColour("#AAA"); // should return True
//            went back and added the following line to check contents of object.
//            System.out.println(ctValidRGB.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Using method getSize() to get size of Pallet of Colours.
    static void getSizeMethodForConstr() {
        try{
            ColourTable ctSizeMethod = new ColourTable(4);
            ctSizeMethod.addColour("#123AAA");
            System.out.println("Size of Array: " + ctSizeMethod.getSize());
//            went back and added the following line to check contents of object.
//            System.out.println(ctValidRGB.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Using method listColours to list all Colours inside the object.
    static void listColoursMethodForConstr() {
        try{
            ColourTable ctListMethod = new ColourTable(4);
            ctListMethod.addColour("#123AAA");
            System.out.println("Size of Array: " + ctListMethod.getSize());
            System.out.println("Elements of ArrayList: " + ctListMethod.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Adding duplicate elements to Array.
    static void addingDuplicatesToArray() {
        try{
            ColourTable ctDuplicate = new ColourTable(4);
            ctDuplicate.addColour("#123AAA");
            ctDuplicate.addColour("#123AAA");
            ctDuplicate.addColour("#123AAA");
            ctDuplicate.addColour("#123AAA");
            ctDuplicate.addColour("#123AAA");
            System.out.println("Size of Array: " + ctDuplicate.getSize());
            System.out.println("Elements of ArrayList: " + ctDuplicate.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
//    Adding unique elements to pass Array Limit Size.
    static void goingOverArrayLimit() {
        try{
            ColourTable ctOverLimit = new ColourTable(4);
            ctOverLimit.addColour("#123AAA");
            ctOverLimit.addColour("#297422");
            ctOverLimit.addColour("#219318");
            ctOverLimit.addColour("#9197A8");
            ctOverLimit.addColour("#F69744");
            System.out.println("Size of Array: " + ctOverLimit.getSize());
            System.out.println("Elements of ArrayList: " + ctOverLimit.listColours());
        } catch (ExceptionInInitializerError e) {
            throw new RuntimeException(e);
        }
    }
}
